#define F_CPU 16000000
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include "UART.h"

void I2C_init() {
	// Set prescaler to 1
	TWSR = 0;

	// Set bit rate register (Baud rate)
	TWBR = ((F_CPU / 100000) - 16) / 2;
}

void I2C_start() {
	// Send start condition
	TWCR = (1 << TWSTA) | (1 << TWEN) | (1 << TWINT);
	while (!(TWCR & (1 << TWINT)));
}

void I2C_stop() {
	// Send stop condition
	TWCR = (1 << TWSTO) | (1 << TWEN) | (1 << TWINT);
}

void I2C_write(uint8_t data) {
	// Load data into TWI data register
	TWDR = data;

	// Enable TWI and clear interrupt flag
	TWCR = (1 << TWEN) | (1 << TWINT);

	// Wait until TWI finish its current job (Write operation)
	while (!(TWCR & (1 << TWINT)));
}

uint8_t I2C_read_ack() {
	// Enable TWI, generation of ack and clear interrupt flag
	TWCR = (1 << TWEN) | (1 << TWINT) | (1 << TWEA);

	// Wait until TWI finish its current job (read operation)
	while (!(TWCR & (1 << TWINT)));

	return TWDR;
}

uint8_t I2C_read_nack() {
	// Enable TWI and clear interrupt flag
	TWCR = (1 << TWEN) | (1 << TWINT);

	// Wait until TWI finish its current job (read operation)
	while (!(TWCR & (1 << TWINT)));

	return TWDR;
}

int main(void) {
	// Initialize I2C
	I2C_init();

	// Replace 0xXX with the slave's address
	uint8_t slave_address_write = 0xc2;
	uint8_t slave_address_read = 0xc3;
	
	UART uart;
	
	char buffer_co2[12];
	char buffer_temp[12];
	char buffer_humidity[12];
	
	while (1) {
		// Start I2C communication
		I2C_start();

		// Send slave address with write operation
		I2C_write(slave_address_write);
		_delay_ms(10);

		// Replace 0xYY with the register address you want to write to
		I2C_write(0x03);
		I2C_write(0x00);

		// Send stop condition
		I2C_stop();

		_delay_ms(50);
		// Start I2C communication again for reading
		I2C_start();

		// Send slave address with read operation
		I2C_write(slave_address_read);

		// Read data and send NACK
		uint8_t co2_mmsb = I2C_read_ack();
		uint8_t co2_mlsb = I2C_read_ack();
		uint8_t co2_lmsb = I2C_read_ack();
		uint8_t co2_llsb = I2C_read_nack();
		
		uint8_t t_mmsb = I2C_read_ack();
		uint8_t t_mlsb = I2C_read_ack();
		uint8_t t_lmsb = I2C_read_ack();
		uint8_t t_llsb = I2C_read_nack();

		uint8_t h_mmsb = I2C_read_ack();
		uint8_t h_mlsb = I2C_read_ack();
		uint8_t h_lmsb = I2C_read_ack();
		uint8_t h_llsb = I2C_read_nack();

		// Send stop condition
		I2C_stop();
		
		// Combine the read bytes to get the full CO2 and temperature measurements
		uint32_t co2_measurement = ((uint32_t)co2_mmsb << 24) | ((uint32_t)co2_mlsb << 16) | ((uint32_t)co2_lmsb << 8) | (uint32_t)co2_llsb;
		uint32_t temperature_measurement = ((uint32_t)t_mmsb << 24) | ((uint32_t)t_mlsb << 16) | ((uint32_t)t_lmsb << 8) | (uint32_t)t_llsb;
		uint32_t humidity_measurement = ((uint32_t)h_mmsb << 24) | ((uint32_t)h_mlsb << 16) | ((uint32_t)h_lmsb << 8) | (uint32_t)h_llsb;

		_delay_ms(50); // Delay for 1 second
		
		sprintf(buffer_co2, "C02:  %lu ppm\r\n", co2_measurement);
		uart.transmitString(buffer_co2);
		
		sprintf(buffer_temp, "Temperature: %lu \r\n", temperature_measurement);
		uart.transmitString(buffer_temp);
		
		sprintf(buffer_humidity, "Humidity: %lu \r\n", humidity_measurement);
		uart.transmitString(buffer_humidity);
		
		_delay_ms(5000);	
	}
	
	
	// UART uart;
	
	// while (1) {
	//	uart.transmitString("Hello, World!\r\n"); // Transmit the string
	//	_delay_ms(10000);     // Delay for 1 second
	//}
}
